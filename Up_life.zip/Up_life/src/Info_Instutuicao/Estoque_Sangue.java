package Info_Instutuicao;

public class Estoque_Sangue {
	public int Id;
	public float Tipo_Bolsa;
	public String Data_Validacao;
	public 
}
