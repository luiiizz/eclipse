package up_life;
public class instituicao {
	
	public String nome;
	
	public int cnpj;
	
	public String endereco;
	
	public void validar_Agendamento(){
		System.out.printf("Validação efetuada");
	}
	
	public void lancar_doacao(String[] args){
		System.out.println("Doação lançada com sucesso");
	}
	
}
