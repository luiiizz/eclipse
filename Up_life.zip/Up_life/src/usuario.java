
public class usuario {
	
	public String nome_completo;
	
	public String email;
	
	public int id_usuario;
	
	public String data_nascimento;

	public static void main(String[] args) {
		System.out.printf("Usuário cadastrado");
	}
}
