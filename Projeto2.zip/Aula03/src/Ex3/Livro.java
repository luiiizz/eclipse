package Ex3;

public class Livro {
	public int id;
	public String titulo;
	public String autor;
	public int num_pag;
	
	public Livro(int id, String titulo, String autor, int num_pag) {
		super();
		this.id = id;
		this.titulo = titulo;
		this.autor = autor;
		this.num_pag = num_pag;
	}
	
	
	

}
