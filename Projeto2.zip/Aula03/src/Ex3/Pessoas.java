package Ex3;

public class Pessoas {
	public String nome;
	public int cpf;
	public String endereco;
	public int celular;
	
	
	public Pessoas(String nome, int cpf, String endereco) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		this.endereco = endereco;
		
	}

}
