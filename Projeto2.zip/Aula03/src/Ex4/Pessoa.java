package Ex4;

public class Pessoa {
	public String nome;
	public int idade;
	public Pessoa pai;
	public Pessoa mae;
	
	
	public Pessoa(String nome, int idade, Pessoa pai, Pessoa mae) {
		super();
		this.nome = nome;
		this.idade = idade;
		this.pai = pai;
		this.mae = mae;
		
	}
	
}
