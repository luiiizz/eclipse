package principal;

import Ex1.produto;
import Ex2.contato;
import Ex3.Pessoas;
import Ex4.Pessoa;


public class aplicacao {	
	

	public static void main(String[] args) throws Exception {
        
		/*
		System.out.println("Hello, World!");
        
        Pessoa p1 = new Pessoa("Luiz", 20, null, null);
        
        Pessoa p2 = new Pessoa("Luiz", 20, p1, null);
        
        System.out.println("Nome: " + p2.nome + "\nIdade:" + p2.idade);*/
		
		

 
    }
      
}
