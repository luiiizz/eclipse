package Ex1;

import Ex1.produto;


public class supermercado {
	
	public String nome;
	public int cnpj;
	public produto venda1; 
	
	public supermercado(String nome, int cnpj) {
		super();
		this.nome = nome;
		this.cnpj = cnpj;
	}
	

}
