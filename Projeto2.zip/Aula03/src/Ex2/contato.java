package Ex2;

public class contato {
	public static String nome;
	public String sobrenome;
	public String empresa;
	public int telefone_trabalho;
	public int celular;
	
	
	public contato(String nome, String sobrenome, String empresa, int telefone_trabalho, int celular) {
		super();
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.empresa = empresa;
		this.telefone_trabalho = telefone_trabalho;
		this.celular = celular;
	}
	 
	
}
