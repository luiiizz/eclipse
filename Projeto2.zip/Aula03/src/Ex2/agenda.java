package Ex2;

import Ex2.contato;

public class agenda {
	public contato contatos;

	public agenda(contato contato1) {
		super();
		this.contatos = contato1;
	}

	public contato getContatos() {
		return contatos;
	}

	public void setContatos(contato contatos) {
		this.contatos = contatos;
	}
	
	
}
