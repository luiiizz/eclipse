package up_life;
public class agendamento {
	
	public static int id_agendamento;
	
	public static int dia;
	
	public static int mes; 
	
	public static int ano;

	public String horario;
	
	public static void exibir_Agendamento( String [] args) {
		System.out.println(id_agendamento);
		
	}

	public void lancar_doacao(Object object) {
	}

    public void validar_Agendamento() {
    }

}

