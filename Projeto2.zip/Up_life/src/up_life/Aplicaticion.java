package up_life;
public class Aplicaticion {

	public static void main(String[] args) {

		agendamento ag1 = new agendamento();
		agendamento.exibir_Agendamento(null);
		
		ag1.lancar_doacao(null);
		ag1.validar_Agendamento();

	}

}
