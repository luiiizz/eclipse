package up_life;
public class farmaceutica {

}
